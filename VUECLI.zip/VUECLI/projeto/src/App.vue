<template>
  <div id='app'>
    <h1>{{ titulo }}</h1>
    <button @click="titulo += '#'">Alterar</button>
  </div>
</template>

<script>
export default {
  data(){
    return{
      titulo: 'Teste de APP'
    }
  }
}
</script>

<style>
  #app{
    background-color: chocolate;
    color: white;
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-size: large;
  }
</style>