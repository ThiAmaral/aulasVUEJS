<template>
  <div id="app">
    <contadores/>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>